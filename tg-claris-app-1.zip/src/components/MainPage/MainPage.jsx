import React from 'react';

const MainPage = () => {
    return (
        <div>
            MAIN
        </div>
    );
};

export default MainPage;